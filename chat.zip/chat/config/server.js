// Módulos utilizados:
var express = require('express');
var consign = require('consign');
var bodyParser = require('body-parser');
var expressValidator = require('express-validator');


// Instanciar o express:
var app = express();

// Definindo as variáveis 'views' e 'view engine' do express:
app.set('view engine', 'ejs');
app.set('views', './app/views');

// Definindo middlewares:
app.use(express.static('./app/public'));
app.use(bodyParser.urlencoded({extended: true}));
app.use(expressValidator());

// Autoload dos diretórios MVC no app:
consign()
    .include('app/routes')
    .then('app/models')
    .then('app/controllers')
    .into(app);

module.exports = app;