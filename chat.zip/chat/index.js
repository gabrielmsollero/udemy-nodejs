var app = require('./config/server');

var server = app.listen(80, () => {
    console.log('Servidor online');
})

var io = require('socket.io')(server); // implementando websocket no projeto.

app.set('io', io);

io.on('connection', function(socket) {
    console.log('Usuário se conectou');

    socket.on('disconnect', function() {
        console.log('Usuário desconectou');

    });

    socket.on('msgParaServidor', function(data){

        // Mostrando a msg na tela de quem enviou
        socket.emit(
            'msgParaCliente', 
            {apelido: data.apelido, mensagem: data.mensagem});

        // Mostrando a msg na tela dos outros participantes
        socket.broadcast.emit(
            'msgParaCliente', 
            {apelido: data.apelido, mensagem: data.mensagem});

        // Atualizando relação de participantes:
        if(parseInt(data.apelido_atualizado_nos_clientes) == 0){
            socket.emit(
                'participantesParaCliente', 
                {apelido: data.apelido});

            // Mostrando a msg na tela dos outros participantes
            socket.broadcast.emit(
                'participantesParaCliente', 
                {apelido: data.apelido});
        }

    });
})