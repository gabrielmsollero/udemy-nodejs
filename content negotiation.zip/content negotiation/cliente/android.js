var http = require('http');

var opcoes = {
    hostname: 'localhost',
    port: 80,
    path: '/',
    method: 'get',
    body: JSON.stringify(dadosForm),
    headers: {
        'Accept': 'application/json',
        'Content-type': 'application/json' // forma de envio de dados do cliente para o servidor via post
    }
}

// var html = 'nome=José';
// var json = {nome: 'José'};
// var string_json = JSON.stringify(json) // converte um json para string

var buffer_corpo_response = [];

var req = http.request(opcoes, function(res) {
    res.on('data', function(chunk) {
        buffer_corpo_response.push(chunk);
    });

    res.on('end', function() {
        var corpo_response = Buffer.concat(buffer_corpo_response).toString();
        console.log(corpo_response);
        console.log(res.statusCode);
    });

    // res.on('error', function() {

    // });
});

// req.write(string_json);
req.end();