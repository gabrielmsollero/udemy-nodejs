module.exports.formulario_inclusao_noticia = (app, req, res) => {
    res.render('admin/form_add_noticia', { validacao: {}, noticia: {}});
}

module.exports.noticias_salvar = (app, req, res) => {
    const noticia = req.body; // proveniente do formulário
    
    // validando o preenchimento do formulario
    req.assert('titulo', 'Título é obrigatório').notEmpty();
    req.assert('autor', 'Autor é obrigatório').notEmpty();
    req.assert('noticia', 'Notícia é obrigatório').notEmpty();
    req.assert('data_noticia', 'Data é obrigatório').notEmpty().isDate({ format: 'MM-DD-YYYY' });
    req.assert('resumo', 'Resumo deve conter entre 10 e 100 caracteres.').len(10, 100);

    const erros = req.validationErrors(); // todos os erros são retornados nessa função

    if(erros) {
        // re-renderizar o preenchimendo do formulário notificando os erros
        res.render('admin/form_add_noticia', {validacao: erros, noticia: noticia}); // passando o formulario preenchido
        return;                                                                     // como parâmetro p/ re-preenchê-lo automaticamente
    }

    const connection = app.src.config.dbConnection();
    const noticiasModel = new app.src.models.NoticiasDAO(connection);

    noticiasModel.salvarNoticia(noticia, (err, result) => {
        res.redirect('/noticias');
    })
}