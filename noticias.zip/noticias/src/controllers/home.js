module.exports.index = (app, req, res) => {
    const connection = app.src.config.dbConnection();
    const noticiasModel = new app.src.models.NoticiasDAO(connection);

    noticiasModel.get5UltimasNoticias((err, result) => {
        console.log(result)
        res.render('home/index', {noticias: result});
    });
}