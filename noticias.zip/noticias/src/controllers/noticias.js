module.exports.noticias = (app, req, res) => {
        const connection = app.src.config.dbConnection();
        const noticiasModel = new app.src.models.NoticiasDAO(connection);

        noticiasModel.getNoticias((err, result) => {
            res.render('noticias/noticias', { noticias: result });
        }); 
}

module.exports.noticia = (app, req, res) => {
        const connection = app.src.config.dbConnection();
        const noticiasModel = new app.src.models.NoticiasDAO(connection);
        const id_noticia = req.query;

        noticiasModel.getNoticia(id_noticia, (err, result) => {
            res.render('noticias/noticia', { noticia: result });
            console.log(result)
        }); 
}