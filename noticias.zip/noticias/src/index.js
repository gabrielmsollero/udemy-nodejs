const app = require('./config/server')

app.listen(3000, () => {
    console.log('Bora carai');
});