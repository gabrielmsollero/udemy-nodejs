const express = require('express');
const consign = require('consign');
const bodyParser = require('body-parser');
const expressValidator = require('express-validator');

const app = express();
app.set('view engine', 'ejs'); // engine que relacionará o JS com o HTML
app.set('views', './src/views'); // explicitando ao express o folder que possui as views

app.use(bodyParser.urlencoded({ extended: true })); // trata os dados da requisição
app.use(expressValidator()); // utilizado p/ validação
app.use(express.static('./src/public')); // explicita ao express um folder de arquivos estáticos (imagens, videos) p/ usar na aplicação

consign() // faz com que todos os arquivos dos diretorios abaixo sejam importados onde forem necessitados na aplicação
    .include('src/routes')
    .then('src/config/dbConnection.js')
    .then('src/models')
    .then('src/controllers')
    .into(app);

module.exports = app;