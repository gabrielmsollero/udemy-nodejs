const mysql = require('mysql');

const connMySQL = () => { // wrapper: embalamos um código em uma função, para executar em um
    return mysql.createConnection({ // momento específico que não seja o momento da importação
        host: 'localhost',
        user: 'root',
        password: 'lolitaking04',
        database: 'portal_noticias'
    });
}

module.exports = () => {
    return connMySQL;
}